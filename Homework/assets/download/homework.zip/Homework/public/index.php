<?php

require_once '../app/start.php';

?>